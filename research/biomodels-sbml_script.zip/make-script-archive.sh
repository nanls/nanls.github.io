cat list-script-archive | zip -@ biomodels-sbml_script.zip
