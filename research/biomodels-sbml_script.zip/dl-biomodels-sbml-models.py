import argparse
import pathlib

import urllib.request
import urllib.parse

import webbrowser

from bs4 import BeautifulSoup


from string import Template



from OLDreports import Report
from easydev import Progress

IDMAX = 1080 # >>> than BIOMD0000001076
IDMAX_timestamp = 20240115 # search for all curated, ordered by name, reverse order

FAILED_NODIV_FILES = []
FAILED_NODIV_CURATION = []
FAILED_NOSBML = []
FAILED_hard404 = []
FAILED_soft404 = []


#################
# Custom exceptions

class NoDiv(Exception):
    pass

class NoSBML(Exception):
    pass

#################

printcount = 0

def printlog(*args, **kwargs) :
    # TODO : make nice printlogs
    # adapted from https://stackoverflow.com/a/26286311

    global printcount
    printcount += 1

    print(" ".join(map(str,args)), **kwargs)

printlog = print

def clear_line():
    # from https://itnext.io/overwrite-previously-printed-lines-4218a9563527
    LINE_UP = '\033[1A'
    LINE_CLEAR = '\x1b[2K'

    global printcount
    for i in range(printcount):
        print(LINE_UP, end=LINE_CLEAR)
    printcount = 0

def print_stats():

    print("FAILED_hard404:", len(FAILED_hard404), FAILED_hard404)
    print("FAILED_soft404:", len(FAILED_soft404), FAILED_soft404)
    print("FAILED_NODIV_FILES:", len(FAILED_NODIV_FILES), FAILED_NODIV_FILES)
    print("FAILED_NODIV_CURATION:", len(FAILED_NODIV_CURATION), FAILED_NODIV_CURATION)
    print("FAILED_NOSBML:", len(FAILED_NOSBML), FAILED_NOSBML)


def dl_sbml(soup, sbml_id, path_dl, force = False):

    if path_dl.is_file() and not force:
        printlog("sbml file already on disk. Skipping.")
        return


    div_Files = soup.find(id="Files")

    if div_Files == None :
        raise NoDiv("no divFiles for {sbml_id}") # next iteration

    trs = div_Files.find('table').tbody.find_all('tr')


    dl_link = None

    for tr in trs :
        # if tr.find_all("td")[0].text in ( f"{sbml_id}_urn.xml" ,  f"{sbml_id}_url.xml" ) : # /!\ nope, not always the case
        if tr.find_all("td")[0].text.endswith(".xml") : # less picky, but seems more reliable.
            dl_link = tr.find_all("td")[3].find_all("a" )[1]["href"]
            printlog("found link, stopping the exploration")
            printlog(dl_link)
            urllib.request.urlretrieve(url_cleanup(dl_link), filename=path_dl)
            # TODO : assert what we just dl it really an sbml file.
            return
            # break #


    # if here, no dl_link found (how could it be ?)
    raise NoSBML(f"no sbml found for {sbml_id}")


def url_cleanup(url):
    #   - no space allowed
    #   - pb with non ascii caracter
    url_cleanbase = "/".join(url.split("/")[:-1])
    url_cleantail = urllib.parse.quote(url.split("/")[-1])
    url_clean = f"{url_cleanbase}/{url_cleantail}"
    return url_clean

def dl_curation(soup, sbml_id, path_dl, force = False) :


    if path_dl.is_file() and not force:
        printlog("curation img already on disk. Skipping.")
        return

    div_Curation = soup.find(id="Curation")

    if div_Curation == None:
        raise NoDiv("no divCuration")  # next iteration

    # base 64 jpg image to file :
    img_to_retrieve = div_Curation.find_next("img")["src"]
    #printlog(img_to_retrieve[0:30])
    urllib.request.urlretrieve(img_to_retrieve, filename=path_dl)




def sbmlfile2libsbmlmodel(sbmlfilepath):
    """
    Open an sbml file with the libsbml

    Argument :
    ----------
    sbmlfilepath (str) : path the the sbml file to open
    Return :
    --------
    model object from libsbml

    Print errors encountered while reading the file.
    Still, the model extracted from the file will be returned.
    """
    reader = libsbml.SBMLReader()
    document = reader.readSBML(sbmlfilepath)

    document.getNumErrors()
    if document.getNumErrors() > 0:
        print("readSBML encountered errors while reading the file.")
        document.printErrors()

    # TODO : add a try except rather than assuming model extraction will be all right despite errors were encountered while reading the SBML file

    model = document.getModel()
    return model

if __name__ == "__main__":

    parser = argparse.ArgumentParser(
        description="Description",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    parser.add_argument(
        "--outfolderpath",
        help="""
            Path to the folder where the report have to be saved. 
            SBML files in the subfolder "sbml".
            Curated images in the subfolder "img".
        """,
        type=str,
        required=True,
    )

    parser.add_argument(
        "--IDMAX",
        help=f"""
            Max BIOMDID to try. Default is {IDMAX} (updated on {IDMAX_timestamp}).
        """,
        type=int,
        required=False,
        default=IDMAX,
    )


    def str2bool(v):
        # from https://stackoverflow.com/a/43357954
        if isinstance(v, bool):
            return v
        if v.lower() in ('yes', 'true', 't', 'y', '1'):
            return True
        elif v.lower() in ('no', 'false', 'f', 'n', '0'):
            return False
        else:
            raise argparse.ArgumentTypeError('Boolean value expected.')

    parser.add_argument(
        "--force",
        help=f"""
            Whether forcing the re-downloading of the files or not.
        """,
        type=str2bool, nargs='?',
        required=False,
        default=False,
    )


    # sys.argv = ["--outfolderpath", "herenowtest"]
    # args = parser.parse_args( sys.argv)
    args = parser.parse_args()

    args.outfolderpath = pathlib.Path(args.outfolderpath)
    args.outfolderpath_img = args.outfolderpath / "img"
    args.outfolderpath_sbml = args.outfolderpath / "sbml"

    args.outfolderpath_img.mkdir(parents=True, exist_ok=True)
    args.outfolderpath_sbml.mkdir(parents=True, exist_ok=True)

    path_report=args.outfolderpath / f"report-infos.html"
    rep = Report()
    rep.add_title(f"Gathering of the sbml files and curation img from the Biomodels website")


    # stop = False # will be set to false as soon as we attempted to dl a file at an url that does not exist.
    i = 0


    p = Progress(args.IDMAX)
    #for i in range(1, args.IDMAX):
    for i in range(1, args.IDMAX):

        # TODO : add nice log
        #p.animate(i+1)
        #clear_line()

        BIOMD_id = "BIOMD{:0>10}".format(str(i))
        printlog("---------- processing", BIOMD_id)

        rep.add_markdown("----------")
        rep.add_markdown(BIOMD_id)

        # query the website and return the html to the variable 'page'

        urlpage = f"https://www.ebi.ac.uk/biomodels/{BIOMD_id}?format=html"
        # did not really get why, but i need to add "?format=html" at the end to get it work. TODO : investigate

        #urlfiles = f"{urlpage}#Files" # ?format=html"
        #urlsbml = f"https://www.ebi.ac.uk/biomodels/services/download/get-files/MODEL6613849442/2/BIOMD0000000001_url.xml

        printlog(urlpage)
        rep.add_markdown(f"<{urlpage}>")



        path_sbml =  pathlib.Path(f"{args.outfolderpath}/sbml/{BIOMD_id}.sbml")
        path_curation = pathlib.Path(f"{args.outfolderpath}/img/{BIOMD_id}_curationimg.jpeg")
        path_curation_forreport = pathlib.Path(f"img/{BIOMD_id}_curationimg.jpeg")

        should_get_soup = args.force or not path_sbml.is_file() or not path_curation.is_file()

        if not should_get_soup :
            printlog("no need to dl anything for this model.")
            rep.add_markdown("no need to dl anything for this model.")

            printlog(f"sbml path = {path_sbml}")
            rep.add_markdown(str(path_sbml))

            printlog(f"curation img path = {path_curation}")
            rep.add_markdown(str(path_curation))
            rep.add_external_figure(path_curation_forreport)
            continue


        req = urllib.request.Request(urlpage)
        req.add_header("accept", "application/xml; charset=utf8")
        # did not really get why, but I need to modify the header... oO TODO : investigate
        # https://www.ebi.ac.uk/biomodels/docs/#/Model-related%20operations/get__modelId_

        # keep retrying with a delay of 1 sec if meeting an error 500
        # https://stackoverflow.com/a/9986206
        #while True:
        #    try:
        #        page = urllib.request.urlopen(req)
        #        break
        #    except urllib.error.HTTPError as detail:
        #        if detail.errno == 500:
        #            time.sleep(1)
        #            print("Has met error 500? Retrying...")
        #            continue
        #    else:
        #        raise


        try:
            page = urllib.request.urlopen(req)
        except urllib.error.HTTPError as detail:
            print(detail)
            rep.add_markdown(repr(detail))
            if detail.errno == 404: # TODO : investigate 404 error with Biomodels. Why no 404 are catched, even when ressource does not exist.
                FAILED_hard404.append(BIOMD_id)
                continue
            elif "404" in str(detail):
                FAILED_soft404.append(BIOMD_id)
                continue
            else :
                raise NotImplementedError
                exit(1)



        # parse the html using beautiful soup and store in variable 'soup'
        # Avoid error " object of type 'Response' has no len() " when BeautifulSoup the page by first getting text instead of bytes
        # https://stackoverflow.com/a/36709275
        soup = BeautifulSoup(page, "html.parser")


        # Find the sbml file within the File tab :

        try :
            dl_sbml(soup, BIOMD_id, path_sbml, args.force)
            printlog(f"sbml path = {path_sbml}")
            rep.add_markdown(str(path_sbml))
        except NoDiv as e:
            print(e)
            rep.add_markdown(repr(e))
            FAILED_NODIV_FILES.append(BIOMD_id)
        except NoSBML as e:
            print(e)
            rep.add_markdown(repr(e))
            FAILED_NOSBML.append(BIOMD_id)

        # find the image within the curation tab :
        try :
            dl_curation(soup, BIOMD_id, path_curation, args.force)
            printlog(f"pathname_forreport = {path_curation_forreport}")
            rep.add_markdown(str(path_curation_forreport))
            rep.add_external_figure(path_curation_forreport)
        except NoDiv as e:
            print(e)
            rep.add_markdown(repr(e))
            FAILED_NODIV_CURATION.append(BIOMD_id)


        # ----------
        # TODO
        # time unit from the sbml file
        #m =sbmlfile2libsbmlmodel(sbml_filepath)
        #units = m.getTimeUnits()
        #unitDefinitions = m.getUnitDefinition(units)
        #rep.add_markdown(
        #    f"The time unit extracted from the sbml is : {units}, {unitDefinitions}"
        #)
        #if not m.isSetTimeUnits():
        #    rep.add_markdown("**The time unit was not set in the sbml**")
        rep.add_markdown(
            f"TODO: extract time unit from the sbml file"
        )
        # ----------



    print("loop is over")

    rep.write_report(
        template_path = "simple.html",
        filename=path_report
    )


    print_stats()

    print("opening in your browser:", path_report)
    webbrowser.open(str(path_report),new=1) # open in a new tab, if possible
