zip biomodels-sbml_result.zip biomodels-sbml-archive_20240116 -r
