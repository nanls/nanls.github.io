#include <stdio.h>

void carreau(void)
{
  printf("\t        *\n");
  printf("\t       ***\n");
  printf("\t      *****\n");
  printf("\t     *******\n");
  printf("\t    *********\n");
  printf("\t   ***********\n");
  printf("\t  *************\n");
  printf("\t ***************\n");
  printf("\t*****************\n");
  printf("\t ***************\n");
  printf("\t  *************\n");
  printf("\t   ***********\n");
  printf("\t    *********\n");
  printf("\t     *******\n");
  printf("\t      *****\n");
  printf("\t       ***\n");
  printf("\t        *\n");
}

int main(void)
{
  int i;

  i = 1;
  while (1) // la condition est toujours vraie.
   {
     carreau();
     i = i + 1;
   }
  
  return 0;
}

