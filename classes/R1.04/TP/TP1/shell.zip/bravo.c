#include <stdio.h>

int main(void)
{
  printf("Bravo, vous avez réussi à exécuter un programme C !\n");

  return 0;
}

